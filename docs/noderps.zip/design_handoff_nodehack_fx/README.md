# Handoff: NodeHack — Mejora de Efectos Visuales (FX Pass v2)

## Overview
Paquete de especificaciones para elevar los efectos "básicos" existentes en la app Flutter
**RiceRDS / nodehack_app** a efectos detallados y de mayor impacto, manteniendo el lenguaje
visual ya establecido (terminal/CRT, glitch, neón sobre fondo casi negro).

**NO se reescribe nada desde cero.** Cada sección parte del código existente, indica el
archivo y widget exacto a modificar, y describe el efecto mejorado con timings, curvas,
colores y estructura. El motor de juego (`nodehack_engine`) NO se toca.

## About the Design Files
Este bundle contiene **especificaciones de diseño**, no código de producción. La tarea es
implementar estas mejoras **dentro del codebase Flutter existente** (`nodehack_app/lib/`),
usando sus patrones ya establecidos:

- `OneShot` (anims.dart) para animaciones de una pasada
- `AnimationController` + `AnimatedBuilder` para loops/secuencias
- `CustomPainter` para efectos procedurales (estática, rayos, partículas)
- Tokens de `NH` (theme/tokens.dart) para TODOS los colores — no inventar hex nuevos
- Regla de oro del proyecto: **el estado base queda visible; solo se anima transform/opacity/paint**. Nada debe quedar en opacity 0 si la animación no corre.

## Fidelity
**High-fidelity sobre código real.** Las especificaciones referencian widgets, líneas y
tokens existentes. Los valores (ms, curvas, alphas, px) son finales salvo ajuste fino a ojo.

## Design Tokens (ya existen en `lib/theme/tokens.dart` — usarlos)
| Token | Hex | Uso |
|---|---|---|
| `NH.bg` | #06080D | fondo app |
| `NH.cardBg` | #05070B | fondo cartas/mesa |
| `NH.panel` | #0B0F17 | paneles |
| `NH.line` | #161C28 | bordes sutiles |
| `NH.fw` | #3FC7EC | cian — CORTAFUEGOS / acciones |
| `NH.xp` | #FF4068 | rojo — EXPLOIT / daño / rival |
| `NH.pl` | #26E6A4 | verde — PULSO / jugador / victoria |
| `NH.nl` | #B061FF | violeta — NULL |
| `NH.amber` | #FFB43F | ámbar — RAM / empate / loading |
| `NH.ink` `NH.ink2` `NH.dim` `NH.dim2` | — | jerarquía de texto |

Tipografías: `NH.disp()` = Chakra Petch (display), `NH.mono()` = JetBrains Mono.
Dispositivo lógico: 390×844 (`NH.device`).

## Tabla de timings global (referencia rápida)
| Efecto | Duración | Curva |
|---|---|---|
| Apertura zoom carta | 260 ms | `Curves.easeOutBack` |
| Cierre zoom carta | 160 ms | `Curves.easeIn` |
| Hit-stop (congelado pre-daño) | 90 ms | — |
| Shake de daño | 550 ms | decaimiento exponencial |
| Aberración cromática | 240 ms | linear |
| Pip explotando | 450 ms (stagger 70 ms) | `Curves.easeOutCubic` |
| Número de daño flotante | 1100 ms | custom (pop + rise + fade) |
| Scramble de título (FLUSH/CORE DUMP) | 650 ms | linear por carácter |
| Stagger de stats en FlushScreen | 90 ms entre filas | `Curves.easeOutCubic` |
| Cascada de puntos de historial | 50 ms por punto | `Curves.easeOutBack` |
| Onda de impacto al soltar carta | 380 ms | `Curves.easeOut` |

---

# 1 · ZOOM DE CARTA (inspección)

**Archivo:** `lib/main.dart` → `_zoomOverlay(CardInstance card)` (~línea 124).
**Estado actual:** overlay instantáneo, negro 85%, `CardView(width: 300)` estática, texto "toca para cerrar". Cero animación.

**Mejora — convertir `_zoomOverlay` en un StatefulWidget `CardZoomOverlay`:**

1. **Entrada (260 ms, easeOutBack):**
   - Fondo: opacity 0→1 en 180 ms; color `NH.a(Colors.black, .88)`.
   - `BackdropFilter` con blur sigma 0→6 (animado con el mismo controller).
   - Carta: scale 0.82→1.0 + translateY 24→0 + rotateX 0.10→0 rad (perspectiva:
     `Matrix4.identity()..setEntry(3, 2, 0.0015)..rotateX(...)`) — sensación de
     "carta que se levanta hacia ti".
2. **Glow de tipo detrás de la carta:** contenedor radial del color
   `NH.ofType(card.type)` (o `#7D8AA0` si es subrutina), `blurRadius` 60,
   alpha que respira .18→.30 con `sin`, loop 2400 ms. Va DETRÁS de `CardView`.
3. **Tilt interactivo:** `onPanUpdate` sobre la carta → rotateX/rotateY
   proporcional a la distancia del dedo al centro, máx ±0.12 rad, con
   `AnimatedScale`/lerp suave de retorno a 0 al soltar (180 ms). La carta se
   siente "física".
4. **Panel de lectura bajo la carta** (entra con delay 120 ms, fade + slideY 12→0):
   - Fila 1: `RUTINA`/`SUBRUTINA` + nombre (`NH.disp` 16/w700).
   - Fila 2 (solo rutinas): chip del ciclo `X ▸ vence a Y` con `Sigil`s (reusar
     `_cycleLegend` de match_screen como referencia visual).
   - Fila 3: texto completo de la carta (`c.txt`, `NH.mono` 10.5, height 1.5) —
     aquí SÍ cabe completo, a diferencia de la carta pequeña.
   - Fila 4: rareza (`c.rar.label`) + `proc` en `NH.dim`.
   - Contenedor: `NH.panel` alpha .8, borde `NH.line`, radius 10, maxWidth 320.
5. **Cierre:** tap fuera O swipe vertical >80 px de la carta (la carta sigue el
   dedo con translate + opacity proporcional; al pasar umbral, anima fuera 160 ms).
6. **Hint:** "toca para cerrar" pulsa opacity .45→.9, loop 1600 ms.
7. **Sonido/háptica:** `HapticFeedback.lightImpact()` al abrir; reusar
   `Sfx.cardPlace` si no hay sfx dedicado.

**Nota:** `GameCard` ya tiene scanline animada con `animate: true` — mantenerla
activa en el zoom (ya lo está por defecto).

---

# 2 · ZOOM AL HISTORIAL DE RONDAS ("modo historia")

**Archivos:** `lib/screens/match_screen.dart` → `_battleTrack()` (~línea 270) y
`lib/screens/flush_screen.dart` → `_historyStrip()`.

### 2a. Battle track expandible (en partida)
**Estado actual:** fila de puntos de 9 px, no interactiva, solo últimas 7 rondas.

**Mejora:** hacer `_battleTrack` tappable → abre overlay `HistoryZoomOverlay`:
- Entrada: el track "se expande" — overlay fade 180 ms + panel scale 0.9→1
  easeOutBack 240 ms, anclado arriba (donde está el track).
- Contenido: timeline vertical de TODAS las rondas. Cada fila:
  `R01 · ▲ TUYA` / `R02 · ▼ RIVAL` / `R03 · = EMPATE` con el color del ganador
  (`NH.pl` / `NH.xp` / `NH.amber`), glyph en círculo de 22 px con glow
  (mismo estilo que `_roundDot` de flush_screen — extraer ese widget a
  `lib/widgets/` y compartirlo).
- **Cascada:** cada fila entra con stagger 50 ms, slideX −10→0 + fade
  (usar `OneShot` con delay por índice, o un solo controller con `Interval`s).
- Línea conectora vertical entre puntos que se "dibuja" de arriba a abajo
  (CustomPaint, progreso 0→1 en 500 ms, color `NH.line` con cabeza brillante `NH.fw`).
- Marcador grande arriba: `TÚ {n} — {n} RIVAL` (`NH.disp` 22/w700).
- Cierre: tap fuera. Solo disponible fuera de la fase `ejecucion`.

### 2b. Cascada en FlushScreen
**Estado actual:** los `_roundDot` aparecen todos a la vez en un `Wrap`.

**Mejora:** cada dot entra con stagger 50 ms: scale 0→1 easeOutBack 300 ms +
glow flash (boxShadow blurRadius 14→7 durante la entrada). El contador
`{you} · {opp}` de la cabecera cuenta desde 0 hasta el valor final
(`TweenAnimationBuilder<int>`, 600 ms, arranca cuando termina la cascada).

---

# 3 · DAÑO (impacto de ronda)

**Archivos:** `lib/widgets/anims.dart` → `HitEffects`; `lib/screens/match_screen.dart`
→ `_floatingDmg()`, `_pip()`, `_dischargeFx()`, `_winnerGlow()`.

### 3a. `HitEffects` (shake + flash) — anims.dart
**Estado actual:** shake horizontal `sin(t·π·6)·(1−t)·7` + flash radial rojo .30.

**Mejora (mantener API `active`/`child`):**
1. **Hit-stop:** al activarse, esperar 90 ms congelado antes de arrancar el shake
   (delay en el `forward`). Vende el peso del golpe.
2. **Shake 2D con rotación:** dx = `sin(t·π·7)·(1−t)²·9`; dy = `cos(t·π·5)·(1−t)²·5`;
   rotación = `sin(t·π·6)·(1−t)²·0.014` rad. Decaimiento cuadrático (no lineal).
3. **Aberración cromática (240 ms):** durante el primer tramo del shake, pintar 2
   copias del child con `Opacity(.35)` + `ColorFiltered` (canal rojo / canal cian)
   desplazadas ±3 px en X opuestas, decayendo a 0. Si el costo de 2 copias del
   subtree es alto en este punto, aplicar solo a un `Container` overlay con
   bandas de color — pero intentar primero con el subtree (la zona es pequeña).
4. **Flash:** subir a .38 de alpha pico y añadir un segundo pulso menor en t≈.5.
5. **Vignette global:** además del flash local, el MatchScreen monta un overlay
   `Positioned.fill` con gradiente radial inverso (bordes `NH.a(NH.xp, .22)` →
   centro transparente), 400 ms, cuando `c.hit != null`. Aplica al perdedor de
   la ronda sea quien sea (es feedback de "hubo daño en la mesa").

### 3b. Pips de integridad — `_pip()` en match_screen.dart
**Estado actual:** el pip roto hace scale 1.5→1 y lerp de color a apagado.

**Mejora:**
1. **Flash blanco previo:** 80 ms a blanco puro con glow `blurRadius` 18 antes
   de empezar a apagarse.
2. **Chispas:** al romper, 4 fragmentos (rects de 3×1.5 px, color `NH.xp`) salen
   del pip con velocidades aleatorias (±40 px/s X, −30..−70 px/s Y), gravedad
   +160 px/s², fade out a 450 ms. Un solo `CustomPaint` por pip roto
   (`_PipBurstPainter`), envuelto en `IgnorePointer` + `Positioned` con
   `clipBehavior: Clip.none`.
3. **Stagger:** si `hit.amount > 1`, cada pip roto arranca 70 ms después del
   anterior (de fuera hacia dentro), no todos a la vez.

### 3c. Número de daño flotante — `_floatingDmg()`
**Estado actual:** "RONDA PERDIDA" + badge "−N INTEGRIDAD" suben 30 px y se desvanecen.

**Mejora:**
1. El "−N" se separa en su propio texto GRANDE: `NH.disp` 36/w700 color `NH.xp`,
   glow `Shadow(blurRadius: 20)`. Pop de entrada scale 1.7→1.0 easeOutBack 200 ms
   (impacto), luego rise −46 px linear + fade desde t .72.
2. "RONDA PERDIDA" queda como subtítulo (tamaño actual), entra 100 ms después.
3. **Jitter:** el bloque completo tiembla ±1.5 px los primeros 250 ms (reusar
   la fase de shake).
4. En la zona del RIVAL (cuando ganas tú) mostrar el equivalente: "−N" verde
   `NH.pl` con "PROCESO DAÑADO" — hoy el rival no muestra número flotante claro;
   unificar: el mismo widget parametrizado por lado/color.

### 3d. Rayo de descarga — `_DischargePainter`
**Estado actual:** rayo principal con segmentos aleatorios + glow + flash final.

**Mejora:**
1. **Ramificaciones:** 2-3 ramas secundarias que salen de puntos aleatorios del
   rayo principal (40% de su longitud restante, strokeWidth 1, alpha .5).
2. **Anillo de impacto:** cuando la cabeza del rayo llega al objetivo (t≈.62),
   dibujar un anillo expandiéndose (radio 0→46 px, stroke 3→0, 300 ms) en el
   punto de impacto + 6 chispas radiales.
3. **Doble pulso:** el rayo parpadea (alpha 1→.4→1) una vez a mitad de recorrido —
   los rayos reales no son constantes.

---

# 4 · PANTALLA DE VICTORIA (FLUSH)

**Archivo:** `lib/screens/flush_screen.dart`.
**Estado actual:** anillo verde expansivo (`_VictoryPainter`), reveal vertical del reporte, stats estáticas.

**Mejora:**
1. **Título con efecto scramble/decode:** "FLUSH" aparece carácter a carácter
   pasando por glyphs aleatorios (`!<>-_\\/[]{}—=+*^?#`) antes de fijarse:
   cada carácter resuelve a los `i·90 + 200` ms; total ~650 ms. Mantener las dos
   copias desplazadas (roja/cian) ya existentes como capa fija.
2. **Anillo doble:** segunda onda 250 ms después de la primera, radio máx .6 del
   ancho, alpha la mitad.
3. **Partículas ascendentes:** 14 motas (`NH.pl`, radio 1–2.5 px, alpha .2–.6)
   suben lentamente en loop durante toda la pantalla (CustomPainter con
   controller `repeat()`, velocidades 12–30 px/s, respawn abajo). Sutiles —
   ambiente, no fuegos artificiales.
4. **Stats en cascada:** cada `_stat` entra con stagger 90 ms (slideX −14→0 +
   fade, easeOutCubic 280 ms), empezando cuando reveal > .6.
5. **Valores con typewriter:** el VALOR de cada stat se escribe carácter a
   carácter (30 ms/char). La FIRMA hex usa el mismo scramble del título (más
   corto, 400 ms).
6. **Botones al final:** REINTENTAR y VOLVER entran (fade + slideY 10→0) tras
   las stats, delay total ~700 ms. REINTENTAR con un pulso de glow inicial
   (boxShadow `NH.a(NH.fw,.3)` blurRadius 18→8, 600 ms) para dirigir el ojo.

---

# 5 · PANTALLA DE DERROTA (CORE DUMP)

**Archivo:** `lib/screens/flush_screen.dart` → `_ShutdownPainter` + `_content`.
**Estado actual:** estática roja + colapso CRT a línea central; reporte entra después. Ya es buena — pulirla:

1. **Afterglow CRT:** tras el colapso, la línea central blanca NO desaparece de
   golpe: persiste como un punto/línea tenue que se desvanece en 800 ms mientras
   el reporte entra (capa extra al final del painter o un `OneShot` separado).
2. **Título con glitch periódico:** "CORE DUMP" hace un micro-glitch cada ~2.2 s
   (120 ms): jitter ±3 px de las copias roja/cian + 2 cortes horizontales
   (ClipRect con translate). Controller `repeat()` con la mayor parte del ciclo
   en reposo.
3. **Stats con flicker de tubo:** cada `_stat` enciende con 2 parpadeos
   (opacity 0→.7→.2→1, 180 ms total) en vez de fade liso — pantalla vieja
   encendiéndose. Mismo stagger 90 ms que en victoria.
4. **Estática residual:** durante el reporte, 2-3 bandas de estática muy tenues
   (`NH.a(NH.xp, .04–.07)`) cruzan la pantalla cada 3-4 s. Ambiente de sistema dañado.

---

# 6 · DRAG & DROP DE CARTAS (programación)

**Archivo:** `lib/screens/match_screen.dart` → `_onCardDown/_onMove/_onUp`,
ghost en `build()` (~línea 247), `_dropSlot()`.
**Estado actual:** ghost plana de 90 px bajo el dedo; slot se ilumina en hover; pop al soltar.

**Mejora:**
1. **Levantamiento:** al activarse el drag (>8 px), la ghost hace scale 1.0→1.12
   en 120 ms + sombra `Colors.black` alpha .6 blurRadius 24 offset (0,12) —
   la carta "despega" de la mano.
2. **Tilt por velocidad:** rotación Z = `(dx_velocidad).clamp(-0.5,0.5) · 0.12` rad,
   suavizada con lerp .2 por frame. La carta se inclina hacia donde se mueve.
3. **Magnetismo de slot:** si la ghost está a <40 px de un slot válido, se atrae
   hacia el centro del slot (lerp .25 por frame hacia el centro) y el slot pasa
   a hover. Soltar dentro del área inflada (+26 px ya existente) confirma.
4. **Slots válidos pulsan:** durante el drag, los slots válidos (de
   `_validTargets`) laten sutilmente: borde alpha .4→.8, loop 900 ms. El jugador
   ve dónde PUEDE soltar sin tocar nada.
5. **Onda al soltar:** al colocar, además del pop existente, un anillo del color
   del tipo de la carta se expande desde el centro del slot (radio 0→52 px,
   stroke 2.5→0, alpha .7→0, 380 ms, CustomPaint encima del slot, IgnorePointer).
6. **Cancelación:** si se suelta fuera de un slot válido, la ghost NO desaparece
   en seco: anima de vuelta a la posición de origen en la mano (translate, 220 ms
   easeOutCubic) mientras la carta de la mano recupera opacity.

---

# 7 · COMPILAR / TRANSICIÓN DE FASES

**Archivo:** `lib/screens/match_screen.dart` → `_wideBtn()`, `_compile()`, `_center()`.

1. **Flash de compilación:** al pulsar COMPILAR, un barrido de luz cruza el botón
   de izquierda a derecha (gradiente blanco alpha .25, 240 ms) antes de cambiar
   a "SELLANDO PROCESO…".
2. **Loading con barra:** los estados loading (`SELLANDO…/REVELANDO…/EJECUTANDO…`)
   muestran una barra de 2 px bajo el texto del botón con un segmento ámbar
   (`NH.amber`) que recorre el ancho en loop (1100 ms, easeInOut).
3. **Tick de fase:** cuando cambia la fase, el pip de fase activo (`_center`)
   hace un pop scale 1→1.6→1 (200 ms) al encenderse — hoy solo cambia de color.

---

## Interactions & Behavior (resumen)
- Todos los overlays nuevos: `IgnorePointer` si son decorativos; `GestureDetector`
  con `HitTestBehavior.opaque` si son modales (patrón ya usado en `_nullPicker`).
- Háptica: `HapticFeedback.lightImpact()` en zoom/colocación; `mediumImpact()` en
  daño recibido; `heavyImpact()` en derrota final. Import `flutter/services.dart`.
- Audio: reusar `AudioService.instance.playSfx(...)` en los nuevos beats si
  existen sfx; no bloquear si no existen.
- **Rendimiento:** un solo `AnimationController` por efecto; `CustomPainter` con
  `shouldRepaint` correcto; nada de `setState` por frame fuera de
  `AnimatedBuilder`. Probar en perfil de release si el shake + aberración +
  partículas coinciden (peor caso: resultado de ronda).

## State Management
No se añade estado de juego. Todo el estado nuevo es **efímero y local** a cada
widget de efecto (controllers). Disparadores ya existentes: `c.hit`,
`c.phase.id`, `c.result`, `c.gameOver`, `widget.outcome` — no cambiar el
controlador (`MatchView`) ni el engine.

## Assets
Ninguno nuevo. Todo es procedural (CustomPaint, transforms, glows con boxShadow).
Tipografías ya cargadas vía `google_fonts` (Chakra Petch, JetBrains Mono).

## Files (referencias en el repo)
| Archivo | Qué se toca |
|---|---|
| `nodehack_app/lib/main.dart` | §1 zoom de carta (`_zoomOverlay` → `CardZoomOverlay`) |
| `nodehack_app/lib/widgets/anims.dart` | §3a `HitEffects` mejorado |
| `nodehack_app/lib/screens/match_screen.dart` | §2a, §3b-d, §6, §7 |
| `nodehack_app/lib/screens/flush_screen.dart` | §2b, §4, §5 |
| `nodehack_app/lib/theme/tokens.dart` | solo lectura (tokens) |
| `nodehack_app/lib/widgets/game_card.dart` | solo lectura (no tocar el render de carta) |

## Orden de implementación sugerido (por impacto/esfuerzo)
1. §1 Zoom de carta — el más visible, autocontenido en main.dart
2. §4 + §5 FlushScreen — segunda impresión más fuerte
3. §3 Daño completo — corazón del game-feel
4. §6 Drag & drop — calidad táctil
5. §2 Historial — nice-to-have
6. §7 Compilar — remate

## Criterios de aceptación
- Sin jank (<16 ms/frame) en un Pixel 4a o equivalente durante resultado de ronda.
- Ningún efecto bloquea input más de lo que ya bloqueaba.
- Si una animación no corre (reduced motion / hot reload), el estado final es
  legible: nada queda invisible o a medio transform.
- Paleta: cero colores nuevos fuera de `NH.*`.
